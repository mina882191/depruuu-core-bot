# DEPRUUU CORE Presence Bot

1. อัปโหลดไฟล์ทั้งหมดเข้าโปรเจกต์ Node.js
2. เพิ่ม Secrets:
   - ชื่อ: DISCORD_TOKEN
   - ค่า: Bot Token ของคุณ
   - ชื่อ: DISCORD_GUILD_ID
   - ค่า: 1552632205740613692
3. กด Run

API ที่เว็บจะเรียกคือ `/api/online`

ใน Discord Developer Portal ต้องเปิด:
- Presence Intent
- Server Members Intent

ห้ามใส่ Bot Token ใน index.html หรือส่งให้ใคร
